#include "feature.h"

MEFeature::MEFeature(MELayer * parent)
    :parent_layer(parent)
{
}

MEFeature::~MEFeature()
{
}

