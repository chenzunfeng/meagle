#ifndef _MSTRING_H_
#define _MSTRING_H_

#ifdef VxWorks
int strncasecmp(const char * str1, const char * str2, size_t len);
#endif

#endif
