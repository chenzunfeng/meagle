/*
** $Id: ogr.h,v 1.5 2006-09-22 03:08:39 jpzhang Exp $
**
** OGR reference header
**
** Copyright (C) 2006 Feynman Software.
**
** Create date: 2006/08/09
*/

#ifndef _OGR_H_
#define _OGR_H_

#include "ogrsf_frmts.h"
#include "ogr_feature.h"
#include "ogr_featurestyle.h"

#endif
