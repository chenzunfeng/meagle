#ifndef _MEAGLE_SEARCH_H_
#define _MEAGLE_SEARCH_H_

extern void open_search_window(HWND hParent, const char* lang);

#endif
